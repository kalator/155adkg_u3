/********************************************************************************
** Form generated from reading UI file 'widget.ui'
**
** Created by: Qt User Interface Compiler version 5.6.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_WIDGET_H
#define UI_WIDGET_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <draw.h>

QT_BEGIN_NAMESPACE

class Ui_Widget
{
public:
    QHBoxLayout *horizontalLayout;
    Draw *Canvas;
    QVBoxLayout *verticalLayout;
    QLabel *label_5;
    QFrame *line_10;
    QPushButton *load_points_button;
    QFrame *line_12;
    QSpacerItem *verticalSpacer_4;
    QFrame *line_11;
    QLabel *label_2;
    QFrame *line_5;
    QPushButton *trg_button;
    QFrame *line_2;
    QSpacerItem *verticalSpacer;
    QFrame *line;
    QLabel *label;
    QFrame *line_3;
    QLabel *label_3;
    QLineEdit *step;
    QCheckBox *main_contours;
    QPushButton *cont_button;
    QFrame *line_6;
    QLabel *label_4;
    QFrame *line_4;
    QPushButton *slope_button;
    QPushButton *aspect_button;
    QPushButton *hyps_button;
    QFrame *line_9;
    QLabel *pic;
    QFrame *line_8;
    QSpacerItem *verticalSpacer_2;
    QFrame *line_7;
    QPushButton *clear_button;

    void setupUi(QWidget *Widget)
    {
        if (Widget->objectName().isEmpty())
            Widget->setObjectName(QStringLiteral("Widget"));
        Widget->resize(1099, 742);
        horizontalLayout = new QHBoxLayout(Widget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        Canvas = new Draw(Widget);
        Canvas->setObjectName(QStringLiteral("Canvas"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(Canvas->sizePolicy().hasHeightForWidth());
        Canvas->setSizePolicy(sizePolicy);
        Canvas->setCursor(QCursor(Qt::ArrowCursor));

        horizontalLayout->addWidget(Canvas);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label_5 = new QLabel(Widget);
        label_5->setObjectName(QStringLiteral("label_5"));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setWeight(75);
        font.setStrikeOut(false);
        font.setKerning(true);
        label_5->setFont(font);

        verticalLayout->addWidget(label_5);

        line_10 = new QFrame(Widget);
        line_10->setObjectName(QStringLiteral("line_10"));
        line_10->setFrameShape(QFrame::HLine);
        line_10->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_10);

        load_points_button = new QPushButton(Widget);
        load_points_button->setObjectName(QStringLiteral("load_points_button"));
        load_points_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(load_points_button);

        line_12 = new QFrame(Widget);
        line_12->setObjectName(QStringLiteral("line_12"));
        line_12->setFrameShape(QFrame::HLine);
        line_12->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_12);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_4);

        line_11 = new QFrame(Widget);
        line_11->setObjectName(QStringLiteral("line_11"));
        line_11->setFrameShape(QFrame::HLine);
        line_11->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_11);

        label_2 = new QLabel(Widget);
        label_2->setObjectName(QStringLiteral("label_2"));

        verticalLayout->addWidget(label_2);

        line_5 = new QFrame(Widget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        trg_button = new QPushButton(Widget);
        trg_button->setObjectName(QStringLiteral("trg_button"));
        trg_button->setEnabled(false);
        trg_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(trg_button);

        line_2 = new QFrame(Widget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        line = new QFrame(Widget);
        line->setObjectName(QStringLiteral("line"));
        line->setFrameShape(QFrame::HLine);
        line->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line);

        label = new QLabel(Widget);
        label->setObjectName(QStringLiteral("label"));

        verticalLayout->addWidget(label);

        line_3 = new QFrame(Widget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        label_3 = new QLabel(Widget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        step = new QLineEdit(Widget);
        step->setObjectName(QStringLiteral("step"));

        verticalLayout->addWidget(step);

        main_contours = new QCheckBox(Widget);
        main_contours->setObjectName(QStringLiteral("main_contours"));
        main_contours->setCursor(QCursor(Qt::PointingHandCursor));
        main_contours->setChecked(true);

        verticalLayout->addWidget(main_contours);

        cont_button = new QPushButton(Widget);
        cont_button->setObjectName(QStringLiteral("cont_button"));
        cont_button->setEnabled(false);
        cont_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(cont_button);

        line_6 = new QFrame(Widget);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        label_4 = new QLabel(Widget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        line_4 = new QFrame(Widget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_4);

        slope_button = new QPushButton(Widget);
        slope_button->setObjectName(QStringLiteral("slope_button"));
        slope_button->setEnabled(false);
        slope_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(slope_button);

        aspect_button = new QPushButton(Widget);
        aspect_button->setObjectName(QStringLiteral("aspect_button"));
        aspect_button->setEnabled(false);
        aspect_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(aspect_button);

        hyps_button = new QPushButton(Widget);
        hyps_button->setObjectName(QStringLiteral("hyps_button"));
        hyps_button->setEnabled(false);
        hyps_button->setCursor(QCursor(Qt::PointingHandCursor));

        verticalLayout->addWidget(hyps_button);

        line_9 = new QFrame(Widget);
        line_9->setObjectName(QStringLiteral("line_9"));
        line_9->setFrameShape(QFrame::HLine);
        line_9->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_9);

        pic = new QLabel(Widget);
        pic->setObjectName(QStringLiteral("pic"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(9);
        sizePolicy1.setHeightForWidth(pic->sizePolicy().hasHeightForWidth());
        pic->setSizePolicy(sizePolicy1);

        verticalLayout->addWidget(pic);

        line_8 = new QFrame(Widget);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_8);

        verticalSpacer_2 = new QSpacerItem(20, 80, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer_2);

        line_7 = new QFrame(Widget);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_7);

        clear_button = new QPushButton(Widget);
        clear_button->setObjectName(QStringLiteral("clear_button"));

        verticalLayout->addWidget(clear_button);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(Widget);

        QMetaObject::connectSlotsByName(Widget);
    } // setupUi

    void retranslateUi(QWidget *Widget)
    {
        Widget->setWindowTitle(QApplication::translate("Widget", "DTM", Q_NULLPTR));
        label_5->setText(QApplication::translate("Widget", "Options", Q_NULLPTR));
        load_points_button->setText(QApplication::translate("Widget", "Load points", Q_NULLPTR));
        label_2->setText(QApplication::translate("Widget", "Triangulation", Q_NULLPTR));
        trg_button->setText(QApplication::translate("Widget", "Go!", Q_NULLPTR));
        label->setText(QApplication::translate("Widget", "Contours", Q_NULLPTR));
        label_3->setText(QApplication::translate("Widget", "Step:", Q_NULLPTR));
        step->setText(QApplication::translate("Widget", "30", Q_NULLPTR));
        main_contours->setText(QApplication::translate("Widget", "Main contours", Q_NULLPTR));
        cont_button->setText(QApplication::translate("Widget", "Go!", Q_NULLPTR));
        label_4->setText(QApplication::translate("Widget", "Analysis", Q_NULLPTR));
        slope_button->setText(QApplication::translate("Widget", "Slope", Q_NULLPTR));
        aspect_button->setText(QApplication::translate("Widget", "Aspect", Q_NULLPTR));
        hyps_button->setText(QApplication::translate("Widget", "Hypsometry", Q_NULLPTR));
        pic->setText(QString());
        clear_button->setText(QApplication::translate("Widget", "Clear all", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Widget: public Ui_Widget {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_WIDGET_H

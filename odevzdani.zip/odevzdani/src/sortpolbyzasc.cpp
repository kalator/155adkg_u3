#include "sortpolbyzasc.h"

SortPolByZAsc::SortPolByZAsc()
{

}

#include "sortbyzasc.h"

SortByZAsc::SortByZAsc()
{

}
